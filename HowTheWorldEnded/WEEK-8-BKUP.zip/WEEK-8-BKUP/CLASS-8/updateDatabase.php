<?php

class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('../db/graffitiGallery.db');
      }
   }
try
{
   $db = new MyDB();
   //$sql_update="UPDATE artCollection SET title = 'Untitled' WHERE pieceID =1";
   //  $ok1 = $db ->exec($sql_update);
   // again we do error checking when we try to execute our SQL statements on the db
  // $sql_delete="DELETE FROM artCollection WHERE artist = 'Martha'";
  //$ok1 = $db ->exec($sql_delete);
  //get the time ...
  $time = date("Y-m-d",time());
  $sql_alter = "ALTER TABLE artCollection ADD COLUMN current_time TEXT NOT NULL DEFAULT '$time'";
  $ok1 = $db ->exec($sql_alter);

   if (!$ok1) die("Cannot execute statement.");
   // if we reach this point then all the data has been updated successfully.
   //echo "UPDATE OF table called artCollection successful";
  //echo "DELETE OPERATION OF table called artCollection successful";
  echo "ADDITION of time column in table artCollection successful";
}
catch(Exception $e)
{
   die($e);
}

?>
