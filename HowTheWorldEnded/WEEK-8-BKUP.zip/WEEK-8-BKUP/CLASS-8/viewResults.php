<?php
// put required html mark up
echo"<html>\n";
echo"<head>\n";
echo"<title> Output from the Grafitti Gallery Database </title> \n";
//include CSS Style Sheet
echo "<link rel='stylesheet' type='text/css' href='css/galleryStyle.css'>";
echo"</head>\n";
// start the body ...
echo"<body>\n";
// place body content here ...
class MyDB extends SQLite3
   {
      function __construct()
      {
         $this->open('../db/graffitiGallery.db');
      }
   }

try
{
   $db = new MyDB();
   $sql_select='SELECT * FROM artCollection';
  // $selectEntryOne  =  "SELECT * FROM artCollection WHERE pieceID = 1";
  //$sqlSelectAfter2003 = "SELECT * FROM artCollection WHERE creationDate >=Date('2002-01-01')";
 // $sqlAfter2003ANDSarah ="SELECT * FROM artCollection WHERE creationDate >=Date('2002-01-01') AND artist = 'Sarah'";
  //$sqlGeoLoc = "SELECT * FROM artCollection WHERE geoLoc = 'Montreal' OR geoLoc = 'London'";
  //$sqlANDOR = "SELECT * FROM artCollection WHERE (creationDate >=Date('2003-01-01') AND artist = 'Sarah')OR(creationDate <=Date('2000-01-01') AND artist = 'Stephen')";
  //$sql_selectA = "SELECT pieceID, title, creationDate FROM artCollection";
  //$sql_selectB = "SELECT artist FROM artCollection";
  //$selectDistinct = "SELECT DISTINCT artist FROM artCollection";
  //$sql_selectC = "SELECT creationDate, artist FROM artCollection WHERE artist = 'Harold' OR artist = 'Sarah'";
//  $sql_selectD = "SELECT creationDate, artist FROM artCollection WHERE artist = 'Harold' OR artist = 'Sarah' ORDER BY creationDate";
//  $count1 ="SELECT artist, COUNT(*) FROM artCollection GROUP BY artist";
//$count2 ="SELECT geoLoc, COUNT(*) FROM artCollection GROUP BY geoLoc";
//$count3 ="SELECT artist, geoLoc, COUNT(*) FROM artCollection GROUP BY artist,geoLoc";
//$count4 = "SELECT COUNT(*) FROM artCollection WHERE creationDate >=Date('2000-01-01')";
//$count5 ="SELECT artist, COUNT(*) FROM artCollection WHERE artist ='Sarah' OR artist ='Harold' GROUP BY artist";
   // the result set
   $result = $db->query($sql_select);
   //$result = $db->query($selectEntryOne);
   //$result = $db->query($sqlSelectAfter2003);
   //$result = $db->query($sqlAfter2003ANDSarah);
   //$result = $db->query($sqlGeoLoc);
   //$result = $db->query($sqlANDOR);
   //$result = $db->query($sql_selectA);
    //$result = $db->query($sql_selectB);
    //$result = $db->query($selectDistinct);
    //$result = $db->query($sql_selectC);
    //$result = $db->query($sql_selectD);
    //  $result = $db->query($count1);
    //$result = $db->query($count2);
  //  $result = $db->query($count5);
   if (!$result) die("Cannot execute query.");
   // fetch first row ONLY...
   $row = $result->fetchArray(SQLITE3_ASSOC);
   print_r($row);
   $result->reset();
echo "<h3> Query Results:::</h3>";
echo"<div id='back'>";
// get a row...
while($row = $result->fetchArray(SQLITE3_ASSOC))
{
   echo "<div class ='outer'>";
   echo "<div class ='content'>";
   // go through each column in this row
   // retrieve key entry pairs
   foreach ($row as $key=>$entry)
   {
     //if the column name is not 'image'
      if($key!="image")
      {
        // echo the key and entry
          echo "<p>".$key." :: ".$entry."</p>";
      }
   }

  // put image in last
    echo "</div>";
    // access by key
    $imagePath = $row["image"];
   echo "<img src = $imagePath\>";
    echo "</div>";
}//end while
echo"</div>";
}

catch(Exception $e)
{
   die($e);
}
echo"</body>\n";
echo"</html>\n";
?>
